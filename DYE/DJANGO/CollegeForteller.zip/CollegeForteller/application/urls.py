# from django.urls import path, include
# from application import views

# urlpatterns = [
#     path('', views.home),
#     path('main/', views.mainPage),
# ]

